const { dependencies } = require("./package.json");
const remotes =
  process.env.NODE_ENV !== "production"
    ? {
        remote: "remote@http://localhost:3001/remoteEntry.js",
        // cart :"cart@http://localhost:3002/remoteEntry.js",
      }
    : {
        remote: "remote@http://abc.com/cart-mfe/remoteEntry.js",
      };
module.exports = {
  name: "host",
  filename: "remoteEntry.js",
  exposes: {},
  remotes,
  shared: {
    ...dependencies,
    react: {
      singleton: true,
      import: "react",
      shareScope: "default",
      requiredVersion: dependencies.react,
    },
    "react-dom": {
      singleton: true,
      requiredVersion: dependencies["react-dom"],
    },
    "react-router-dom": {
      singleton: true,
      requiredVersion: dependencies["react-router-dom"],
    },
  },
};
