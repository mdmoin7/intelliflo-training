import { lazy, Suspense } from "react";
const RemoteCmp = lazy(() => import("remote/Module"));

export default function App() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <div>
        <div>Host App</div>
        <RemoteCmp />
      </div>
    </Suspense>
  );
}
