export default function Hello() {
  return <div>Hello from App 1</div>;
}
