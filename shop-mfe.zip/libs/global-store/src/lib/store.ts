import { configureStore } from '@reduxjs/toolkit';
import userReducer from './slices/userSlice';

// Configure and export the store
export const store = configureStore({
  reducer: {
    user: userReducer,
  },
});

// Export types for hooks
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
