import { createSlice, PayloadAction } from '@reduxjs/toolkit';

// Define initial state
interface UserState {
  name: string;
  loggedIn: boolean;
}

const initialState: UserState = {
  name: '',
  loggedIn: false,
};

// Define a slice
const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUser: (
      state,
      action: PayloadAction<{ name: string; loggedIn: boolean }>
    ) => {
      state.name = action.payload.name;
      state.loggedIn = action.payload.loggedIn;
    },
    clearUser: (state) => {
      state.name = '';
      state.loggedIn = false;
    },
  },
});

// Export actions
export const { setUser, clearUser } = userSlice.actions;
export default userSlice.reducer;
