# global-store

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build global-store` to build the library.
