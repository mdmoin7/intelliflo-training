import { useEffect } from 'react';
import { eventBus } from './event-bus';

export function useEventBus(
  eventName: string,
  callback: (payload: any) => void
) {
  useEffect(() => {
    const unsubscribe = eventBus.subscribe(eventName, callback);
    // unsubscribe on unmounting
    return () => {
      unsubscribe();
    };
  }, [eventName, callback]);
}
