type Callback = (payload: any) => void;
class EventBus {
  // {test_event:[sub1, sub2],demo_event:[sub1, sub2]}
  private events: { [eventName: string]: Callback[] } = {};
  // used by subscribers
  subscribe(eventName: string, callback: Callback) {
    // check if event already enlisted
    if (!this.events[eventName]) {
      // if event does not exist, create a new set of subscribers array
      this.events[eventName] = [];
    }
    // add new subscriber to the set of subscribers for the event
    this.events[eventName].push(callback);
    // return an unsubscribe function
    return () => {
      this.events[eventName] = this.events[eventName].filter(
        (cb) => cb !== callback
      );
    };
  }

  // publisher
  emit(eventName: string, payload: any) {
    const callbacks = this.events[eventName];
    // callbacks are the subscribers
    if (callbacks) {
      // publishing notification to all subscribers with the data
      callbacks.forEach((cb) => cb(payload));
    }
  }
}
export const eventBus = new EventBus();
