# event-bus

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build event-bus` to build the library.
