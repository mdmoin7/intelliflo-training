import { DetailedHTMLProps, PropsWithChildren, SyntheticEvent } from 'react';
import './ui.css';

type Props = {
  type: 'primary' | 'secondary' | 'default';
  size: 'small' | 'medium' | 'large';
  click: (event: SyntheticEvent) => void;
} & PropsWithChildren;
export function Button({ size, type, click, children }: Props) {
  return (
    <button className={`btn btn-${size} btn-${type}`} onClick={click}>
      {children}
    </button>
  );
}
