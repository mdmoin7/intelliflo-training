import { eventBus, useEventBus } from '@shop-app/event-bus';
import { Button } from '@shop-app/ui';
export function App() {
  useEventBus('my-event', (data) => {
    console.log('Subscriber Cart', data);
  });
  return (
    <div>
      <Button
        type="primary"
        size="medium"
        click={() => eventBus.emit('my-event', 'Hello from cart')}
      >
        Emit Event
      </Button>
    </div>
  );
}

export default App;
