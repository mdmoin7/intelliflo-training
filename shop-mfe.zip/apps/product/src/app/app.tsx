// Uncomment this line to use CSS modules
// import styles from './app.module.css';
import NxWelcome from './nx-welcome';

export function App() {
  const emitEvent = () => {
    const event = new CustomEvent('product_mfe_event', {
      detail: { message: 'this works from product' },
    });
    window.dispatchEvent(event);
  };
  return (
    <div>
      <h1>Product MFE</h1>
      <button onClick={emitEvent}>Product Click</button>
    </div>
  );
}

export default App;
