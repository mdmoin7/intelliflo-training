// Uncomment this line to use CSS modules
// import styles from './app.module.css';
import NxWelcome from './nx-welcome';

export function App() {
  return (
    <div>
      <NxWelcome title="checkout" />
    </div>
  );
}

export default App;
