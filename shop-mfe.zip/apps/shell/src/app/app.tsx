import * as React from 'react';
import NxWelcome from './nx-welcome';
import { Link, Route, Routes } from 'react-router-dom';
import { useEventBus } from '@shop-app/event-bus';

const Product = React.lazy(() => import('product/Module'));
const Checkout = React.lazy(() => import('checkout/Module'));
const Cart = React.lazy(() => import('cart/Module'));

export function App() {
  const [message, setMessage] = React.useState('');
  useEventBus('my-event', (data) => {
    console.log('Subscriber Host', data);
  });
  window.addEventListener('product_mfe_event', (data: any) => {
    console.log('Received event from product MFE:', data);
    setMessage(data.detail.message);
  });

  return (
    <React.Suspense fallback={<div>Loading...</div>}>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/product">Product</Link>
        </li>
        <li>
          <Link to="/checkout">Checkout</Link>
        </li>
        <li>
          <Link to="/cart">Cart</Link>
        </li>
      </ul>
      <h1>Welcome to MFE's : {message}</h1>
      <Routes>
        <Route path="/" element={<NxWelcome title="shell" />} />
        <Route path="/product" element={<Product />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/cart" element={<Cart />} />
      </Routes>
    </React.Suspense>
  );
}

export default App;
