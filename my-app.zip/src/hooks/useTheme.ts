import { useContext } from "react";
import { ThemeContext } from "../context";

function useTheme() {
  const theme = useContext(ThemeContext);
  const altTheme = theme === "light" ? "dark" : "light";
  const bgColor = theme === "light" ? "bg-white" : "bg-gray-900";
  const color = theme === "light" ? "text-gray-600" : "text-white";
  return { bgColor, color, theme, altTheme };
}
export default useTheme;
