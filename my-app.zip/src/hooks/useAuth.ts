import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../store";
import Axios from "axios";
import { clearUserSession, setUserSession } from "../store/slices/userSlice";
import { useNavigate } from "react-router-dom";

function useAuth() {
  const isLoggedIn = useSelector((state: RootState) => state.user !== null);
  const user = useSelector((state: RootState) => state.user);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const login = async (email: string, password: string) => {
    try {
      const data = { email, password };
      const url = "";
      // const res = await Axios.post(url, data);
      dispatch(setUserSession({ user: email }));
      navigate("/");
    } catch (err) {
      console.error("Error logging in", err);
    }
  };

  const logout = () => {
    dispatch(clearUserSession());
    navigate("/");
  };

  return { isLoggedIn, login, user, logout };
}
export default useAuth;
