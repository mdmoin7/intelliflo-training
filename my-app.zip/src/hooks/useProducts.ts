import { useState, useEffect } from "react";
import { getProducts } from "../services/ProductService";
import { ProductType } from "../types";

// hook name : should start with useHookName
function useProducts() {
  const [plist, setPlist] = useState<ProductType[]>([]);
  const getData = async () => {
    try {
      const { data } = await getProducts();
      setPlist(data);
    } catch (err) {
      console.error("Error fetching products", err);
    }
  };
  useEffect(() => {
    getData();
  }, []);
  return { plist, getData };
}
export default useProducts;
