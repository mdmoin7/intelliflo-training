import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { chunk } from "lodash";
export default function usePaginate<T>(data: T[], pageSize = 10) {
  const [queryParam, setQueryParams] = useSearchParams();
  const [page, setPage] = useState(1);
  const [chunkData, setChunkData] = useState<Array<T[]>>([]);
  const [pageData, setPageData] = useState<T[]>([]);

  useEffect(() => {
    if (queryParam.has("page")) {
      setPage(parseInt(queryParam.get("page") as string));
    }
  }, [queryParam]);

  useEffect(() => {
    if (data && data.length > 0) {
      setChunkData(chunk(data, pageSize));
    }
  }, [data, pageSize]);

  useEffect(() => {
    setPageData(chunkData[page - 1]);
  }, [page, chunkData]);

  return { setQueryParams, page, data: pageData };
}
