import { createSlice } from "@reduxjs/toolkit";

const currencySlice = createSlice({
  name: "currency",
  initialState: "INR",
  reducers: {
    // reducer_actions : logic to update the data
    changeCurrency: (state, action) => {
      // state : current data inside the store
      // action : contains action related information
      // return the updated data to the store
      // payload : any data that needs to be sent to the store
      return action.payload;
    },
  },
});
// actions are used by components to make data changes inside the store
export const { changeCurrency } = currencySlice.actions;
// reducer is used by the store
export default currencySlice.reducer;
