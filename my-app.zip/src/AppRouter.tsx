import { Route, Routes } from "react-router-dom";
import Demo from "./Demo";
import Checkout from "./containers/Checkout";
import ErrorPage from "./containers/ErrorPage";
import PrivateRoute from "./components/PrivateRoute";
import ProductDetail from "./containers/ProductDetail";
import { lazy, Suspense } from "react";
import Login from "./containers/Login";

const LazyProductList = lazy(() => import("./containers/ProductList"));

function AppRouter() {
  return (
    <div className="w-full mx-auto px-4 py-4">
      <Suspense fallback={<h1>Loading...</h1>}>
        <Routes>
          <Route path="/" element={<Demo />} />
          <Route path="/login" element={<Login />} />
          <Route path="/products" element={<LazyProductList />} />
          <Route path="/detail/:pid" element={<ProductDetail />} />
          <Route
            path="/checkout"
            element={
              <PrivateRoute>
                <Checkout />
              </PrivateRoute>
            }
          />
          <Route path="*" element={<ErrorPage />} />
        </Routes>
      </Suspense>
    </div>
  );
}
export default AppRouter;
