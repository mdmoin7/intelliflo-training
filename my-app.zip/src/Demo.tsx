import { useEffect, useState } from "react";
import Card from "./components/Card";

function Demo() {
  // a component should return something always
  // return as a single html element
  const name = "mike";
  const [count, setCount] = useState(0);
  console.log("render called");
  // mounting the component
  useEffect(
    () => {
      console.log("effect function called");
    },
    [
      // dependencies : which value changes are going to impact the execution of the effect function
      // empty_array : on load : executes only once
    ]
  );
  // updating
  useEffect(() => {
    console.log("effect function called");
  }, [count]);
  // unmounting the component
  useEffect(() => {
    return () => {
      console.log("unmounting effect function called");
    };
  }, []);
  return (
    <Card>
      <h1>Demo component</h1>
      <p>Some more content here</p>
      <p>Hello from {name}</p>
      <p>{name.toUpperCase()}</p>
      <p>{9 + 8}</p>
      <button onClick={() => setCount(count + 1)}>Count</button>
    </Card>
  );
}
export default Demo;
