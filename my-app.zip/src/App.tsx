import { useEffect, useState } from "react";
import ThemeSwitch from "./components/ThemeSwitch";
import { ThemeContext } from "./context";
import AppRouter from "./AppRouter";
import { BrowserRouter } from "react-router-dom";
import Menu from "./components/Menu";
import { Provider } from "react-redux";
import { persistor, store } from "./store";
import Currency from "./components/Currency";
import { PersistGate } from "redux-persist/integration/react";
function App() {
  console.log("app rendered");
  const [theme, setTheme] = useState("light");
  useEffect(() => {
    if (localStorage.getItem("theme")) {
      setTheme(localStorage.getItem("theme") as string);
    }
  }, []);

  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <BrowserRouter>
          <ThemeContext.Provider value={theme}>
            <Menu>
              <Currency />
              <ThemeSwitch changeTheme={(t) => setTheme(t)} />
            </Menu>
            <AppRouter />
          </ThemeContext.Provider>
        </BrowserRouter>
      </PersistGate>
    </Provider>
  );
}

export default App;
