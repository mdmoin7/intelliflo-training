import { Formik, Form, Field, ErrorMessage } from "formik";
import useAuth from "../hooks/useAuth";
import * as Yup from "yup";

const LoginSchema = Yup.object().shape({
  email: Yup.string().required("Email is required").email(),
  password: Yup.string()
    .required("Password is required")
    .min(6, "Password must be at least 6 characters long"),
});

function Login() {
  const { login } = useAuth();
  return (
    <Formik
      validationSchema={LoginSchema}
      initialValues={{ email: "", password: "" }}
      onSubmit={({ email, password }) => login(email, password)}
    >
      <Form>
        <Field name="email" placeholder="Enter email" />
        <ErrorMessage name="email" />

        <Field name="password" type="password" placeholder="Enter password" />
        <ErrorMessage name="password" />

        <button type="submit">Login</button>
      </Form>
    </Formik>
  );
}
export default Login;
