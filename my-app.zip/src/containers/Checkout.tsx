import { SyntheticEvent, useEffect, useRef, useState } from "react";

function Checkout() {
  const [name, setName] = useState("");
  const emailRef = useRef<HTMLInputElement>(null);

  const saveData = (ev: SyntheticEvent) => {
    ev.preventDefault(); // prevent form from reloading the page
    console.log("form submission logic here", name, emailRef.current?.value);
  };

  useEffect(() => {
    if (emailRef.current) {
      emailRef.current.focus(); // autofocus the input field on mount
    }
  }, [emailRef]);

  return (
    <form onSubmit={(e) => saveData(e)}>
      {/* Controlled */}
      <input
        type="text"
        placeholder="enter name"
        onChange={(e) => setName(e.target.value)}
      />
      {name === "" ? <small>Name is required</small> : null}
      {/* ref :gets the DOM object reference */}
      <input type="text" placeholder="enter email" ref={emailRef} />
      {emailRef && emailRef.current?.value === "" ? (
        <small>Email is required</small>
      ) : null}
      <button type="submit">Submit</button>
    </form>
  );
}
export default Checkout;
