import { memo } from "react";
import Product from "../components/Product";
import useProducts from "../hooks/useProducts";
import { useNavigate } from "react-router-dom";
import Pagination from "../components/Pagination";
import usePaginate from "../hooks/usePaginate";
import { ErrorBoundary } from "react-error-boundary";

function ProductList() {
  // const [state_variable, updateStateFunction]=useState(initial_value);
  // updateStateFunction : update the state immutably (shallow update)
  // deep udpates: immer js
  console.log("productlist rendered");
  const { plist } = useProducts();
  const navigate = useNavigate();
  const { data, setQueryParams, page } = usePaginate(plist);
  return (
    <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6 sm:py-24 lg:max-w-7xl lg:px-8">
      <div className="mt-6 grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3 xl:gap-x-8">
        {data &&
          data.map((item) => (
            <Product
              key={item.productId}
              data={item}
              btnClick={(id) => {
                console.log("add to cart", id);
                navigate("/cart");
              }}
            />
          ))}
      </div>
      <div className="flex justify-center my-4">
        <Pagination
          size={10}
          currentPage={page}
          pageChange={(p) => setQueryParams({ page: p.toString() })}
        />
      </div>
    </div>
  );
}
export default memo(ProductList);
