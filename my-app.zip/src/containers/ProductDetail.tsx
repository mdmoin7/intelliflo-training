import { useParams } from "react-router-dom";
import Card from "../components/Card";

function ProductDetail() {
  const params: any = useParams(); // path params : /detail/1234
  // useEffect(() => {}, [params]);
  return (
    <Card>
      <h1>Product detail</h1>
      <h3>PID: {params.pid}</h3>
    </Card>
  );
}
export default ProductDetail;
