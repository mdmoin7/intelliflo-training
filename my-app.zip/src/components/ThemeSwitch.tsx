import { useEffect } from "react";
import useTheme from "../hooks/useTheme";
type Props = {
  changeTheme: (theme: string) => void;
};
function ThemeSwitch({ changeTheme }: Props) {
  const { bgColor, altTheme, color } = useTheme();
  useEffect(() => {
    // side effects : anywhere where react has control
    document.body.className = bgColor;
  }, [bgColor]);
  return (
    <button
      className={`${color} ${bgColor} border border-blue-700 rounded px-2 py-1 uppercase me-3`}
      onClick={() => {
        changeTheme(altTheme);
        localStorage.setItem("theme", altTheme);
      }}
    >
      {altTheme}
    </button>
  );
}
export default ThemeSwitch;
