import { memo } from "react";
import { ProductType } from "../types";
import Card from "./Card";
import Rating from "./Rating";
import { useSelector } from "react-redux";
import { RootState } from "../store";

type Props = {
  data: ProductType;
  btnClick?: (id: number) => void;
};
function Product({ data, btnClick }: Props) {
  // state : represents the entire store
  const code = useSelector((state: RootState) => state.currency);

  const click = () => {
    return btnClick ? btnClick(data.productId) : null;
  };

  console.log("product rendered");
  return (
    <Card>
      <div className="group relative shadow p-3 rounded">
        <img
          src={data.productImage}
          alt={data.productName}
          className="aspect-square w-full rounded-md bg-gray-200 object-cover group-hover:opacity-75 lg:aspect-auto lg:h-80"
        />
        <div className="mt-4 flex justify-between">
          <div>
            <h3 className="text-sm capitalize">{data.productName}</h3>
            <p className="mt-1 text-sm">
              <Rating value={data.rating} />
            </p>
          </div>
          <p className="text-sm font-medium">
            {code}
            {data.productPrice}
          </p>
        </div>
        <button
          className="px-4 py-1 border border-blue-700 rounded w-full mt-3"
          onClick={click}
        >
          Add to Cart
        </button>
      </div>
    </Card>
  );
}

export default memo(Product);
