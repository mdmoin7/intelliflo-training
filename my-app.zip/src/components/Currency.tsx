import { useDispatch } from "react-redux";
import { changeCurrency } from "../store/slices/currencySlice";
import useTheme from "../hooks/useTheme";

export default function Currency() {
  const codes = ["INR", "USD", "EUR", "GBP", "CAD"];
  const { color, bgColor } = useTheme();
  // every action must be dispatched
  const dispatch = useDispatch();
  return (
    <select
      onChange={(e) => dispatch(changeCurrency(e.target.value))}
      className={`rounded px-2 py-1 ${bgColor} ${color} border`}
    >
      {codes.map((item) => (
        <option key={item} value={item}>
          {item}
        </option>
      ))}
    </select>
  );
}
