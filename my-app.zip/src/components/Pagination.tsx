type Props = {
  size: number;
  pageChange: (page: number) => void;
  currentPage: number;
};
export default function Pagination({ size, pageChange, currentPage }: Props) {
  const pages = Array(size).fill(0);
  return (
    <div className="flex flex-row">
      {pages.map((p, i) => (
        <button
          className={`border border-gray-400 rounded me-1 w-10 ${
            currentPage - 1 === i ? "bg-blue-200" : ""
          }`}
          onClick={() => pageChange(i + 1)}
        >
          {i + 1}
        </button>
      ))}
    </div>
  );
}
