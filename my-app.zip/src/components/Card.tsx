import { PropsWithChildren } from "react";
import useTheme from "../hooks/useTheme";

function Card({ children }: PropsWithChildren) {
  const { color } = useTheme();
  // context, state, props : any of these change : component re-renders
  // memo : only re-renders when props have changed

  console.log("card rendered");

  return <div className={`${color} bg-red`}>{children}</div>;
}
export default Card;
