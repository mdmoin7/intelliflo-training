import { createSlice } from "@reduxjs/toolkit";

const currencySlice = createSlice({
  name: "currency",
  initialState: "INR",
  reducers: {
    // reducer_actions : functions which are used to make data changes inside the store
    // action_name: (state: current data inside the store, action: data related to the action initiated)=>{
    // return updated data to the store
    // }
    updateCurrency: (state, action) => {
      return action.payload; // action.payload is the data passed to the action
    },
  },
});
// actions are used by the component to make the data changes inside the store
export const { updateCurrency } = currencySlice.actions;
// reducer is used by the store
export default currencySlice.reducer;
