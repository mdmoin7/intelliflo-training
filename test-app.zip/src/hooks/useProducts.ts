import { useState, useEffect } from "react";
import { getProducts } from "../services/ProductService";
import { ProductType } from "../types";
import { useSearchParams } from "react-router-dom";
import { chunk } from "lodash"; // npm i lodash, npm i -D @types/lodash

function useProducts() {
  const [data, setData] = useState<Array<ProductType[]>>([]);
  const [plist, setPlist] = useState<ProductType[]>([]);
  const [queryParams, setQueryParams] = useSearchParams(); // /products?page=10
  const [loading, setIsLoading] = useState(false);
  const [page, setPage] = useState(1);
  const getData = async () => {
    try {
      const response = await getProducts();
      setIsLoading(true);
      setData(chunk(response.data, 10));
      setIsLoading(false);
    } catch (e) {
      setIsLoading(false);
      console.log("error", e);
    }
  };
  const updatePageNo = (pg: number) => {
    setQueryParams({ page: pg.toString() });
  };

  useEffect(() => {
    getData();
  }, []);

  useEffect(() => {
    if (queryParams.has("page")) {
      setPage(Number(queryParams.get("page")));
    }
  }, [queryParams]);

  useEffect(() => {
    if (data.length > 0) {
      setPlist(data[page - 1]);
    }
  }, [page, data]);
  return { plist, isLoading: loading, updatePageNo, page, data };
}
export default useProducts;
