import { useCallback, useContext, useEffect } from "react";
import { CurrencyContext } from "../context";
function useCurrency() {
  const code = useContext(CurrencyContext);

  const setStorageData = (c: string) => {
    localStorage.setItem("currency", c);
  };
  const getStorageData = () => {
    if (localStorage.getItem("currency")) {
      return localStorage.getItem("currency") as string;
    }
    return "INR";
  };
  const getExchangeValue = useCallback(
    (price: number) => {
      switch (code) {
        case "USD":
          return (0.012 * price).toFixed(2);
        case "GBP":
          return (0.0093 * price).toFixed(2);
        case "EUR":
          return (0.011 * price).toFixed(2);
        case "CAD":
          return (0.017 * price).toFixed(2);
        default:
          return price;
      }
    },
    [code]
  );
  const getFormattedValue = (price: number) =>
    `${code}${getExchangeValue(price)}`;

  return { code, getFormattedValue, getStorageData, setStorageData };
}
export default useCurrency;
