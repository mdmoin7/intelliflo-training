import { renderHook, act } from "@testing-library/react-hooks";
import { CurrencyContext } from "../context"; // Adjust the import path as necessary
import useCurrency from "./useCurrency"; // Adjust the import path as necessary
import React, { ReactNode } from "react";

describe("useCurrency Hook", () => {
  beforeEach(() => {
    // Clear localStorage before each test
    localStorage.clear();

    // Mock localStorage methods
    const setItemMock = jest.fn();
    const getItemMock = jest.fn();
    const removeItemMock = jest.fn();
    const clearMock = jest.fn();

    Object.defineProperty(window, "localStorage", {
      value: {
        setItem: setItemMock,
        getItem: getItemMock,
        removeItem: removeItemMock,
        clear: clearMock,
      },
      writable: true,
    });
  });

  // Define a type for the wrapper props
  const wrapper = ({ children }: { children: ReactNode }) => (
    <CurrencyContext.Provider value="INR">{children}</CurrencyContext.Provider>
  );

  test("returns default currency when localStorage is empty", () => {
    const { result } = renderHook(() => useCurrency(), { wrapper });

    expect(result.current.code).toBe("INR");
    expect(result.current.getStorageData()).toBe("INR");
  });

  test("formats value correctly for different currencies", () => {
    const wrapper = ({ children }: { children: ReactNode }) => (
      <CurrencyContext.Provider value="USD">
        {children}
      </CurrencyContext.Provider>
    );

    const { result } = renderHook(() => useCurrency(), { wrapper });

    const price = 100;
    expect(result.current.getFormattedValue(price)).toBe("USD1.20"); // Assuming USD conversion is 0.012
  });

  test("sets currency in localStorage", () => {
    const { result } = renderHook(() => useCurrency(), { wrapper });

    act(() => {
      result.current.setStorageData("EUR");
    });

    expect(window.localStorage.setItem).toHaveBeenCalledWith("currency", "EUR");
  });
});
