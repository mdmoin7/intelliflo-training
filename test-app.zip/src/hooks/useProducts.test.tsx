import { renderHook, act } from "@testing-library/react-hooks";
import useProducts from "./useProducts";
import { getProducts } from "../services/ProductService";
import { chunk } from "lodash";

// Mock dependencies
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"), // use actual for all non-hook parts
}));
jest.mock("../services/ProductService", () => ({
  getProducts: jest.fn(),
}));

describe("useProducts Hook", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("should initialize with correct default states", () => {
    const { result } = renderHook(() => useProducts());
    const { data, plist, isLoading, page } = result.current;

    expect(data).toEqual([]);
    expect(plist).toEqual([]);
    expect(isLoading).toBe(false);
    expect(page).toBe(1);
  });

  it("should fetch and chunk product data on mount", async () => {
    const mockData = Array.from({ length: 25 }, (_, i) => ({ id: i + 1 }));
    (getProducts as jest.Mock).mockResolvedValueOnce({ data: mockData });

    const { result, waitForNextUpdate } = renderHook(() => useProducts());
    await waitForNextUpdate(); // Wait for getData to complete.

    expect(getProducts).toHaveBeenCalled();
    expect(result.current.data).toEqual(chunk(mockData, 10));
    expect(result.current.isLoading).toBe(false);
  });

  it("should handle errors during data fetching", async () => {
    const mockError = new Error("Network Error");
    (getProducts as jest.Mock).mockRejectedValueOnce(mockError);

    const { result, waitForNextUpdate } = renderHook(() => useProducts());
    await waitForNextUpdate();

    expect(result.current.isLoading).toBe(false);
    // Optional: Verify error logs if needed
  });
});
