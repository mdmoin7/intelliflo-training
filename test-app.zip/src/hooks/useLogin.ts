// import { useDispatch } from "react-redux";
import { createSession } from "../store/slices/userSlice";
import Axios from "axios";
// import { useNavigate } from "react-router-dom";

function useLogin() {
  // const dispatch = useDispatch();
  // const navigate = useNavigate();
  const login = async (email: string, password: string) => {
    try {
      const apiKey = "AIzaSyD4RrqfZlHo95TJaarFHx1-bYc_kWwYzcw";
      const url =
        "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" +
        apiKey;
      const data = { email, password, returnSecureToken: true };
      const res = await Axios.post(url, data);
      // dispatch(createSession(res.data));
      // navigate("/");
    } catch (e) {
      console.log("login error", e);
    }
  };
  return login;
}
export default useLogin;
