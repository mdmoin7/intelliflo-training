import { renderHook, act } from "@testing-library/react";
import useCounter from "./useCounter";

describe("useCounter hook", () => {
  test("initializes the counter with value as 3", () => {
    const { result } = renderHook(() => useCounter(3));
    expect(result.current.count).toBe(3);
  });
  test("initializes the counter with value as 0", () => {
    const { result } = renderHook(() => useCounter());
    expect(result.current.count).toBe(0);
  });
  test("increments counter with value 1", () => {
    const { result } = renderHook(() => useCounter(3));
    act(() => {
      result.current.increment();
    });
    expect(result.current.count).toBe(4);
  });
});
