import { renderHook, act } from "@testing-library/react";
import axios from "axios";
import useLogin from "./useLogin";

jest.mock("axios");

describe("useLogin Hook", () => {
  test("should call the API and handle success", async () => {
    const mockResponse = {
      data: { idToken: "mock-token", email: "test@example.com" },
    };
    (axios.post as jest.Mock).mockResolvedValue(mockResponse);

    const { result } = renderHook(() => useLogin());

    await act(async () => {
      await result.current("test@example.com", "password123");
    });

    expect(axios.post).toHaveBeenCalledWith(
      expect.stringContaining("https://identitytoolkit.googleapis.com"),
      {
        email: "test@example.com",
        password: "password123",
        returnSecureToken: true,
      }
    );
  });
});
