import { useEffect, useState } from "react";

function Demo() {
  // every component must return something always
  // whatever we return is rendered in the ui
  // return only one single consolidated html
  const name = "mike";
  const [count, setCount] = useState(0);
  const [count1, setCount1] = useState(0);
  // useEffect(effect_function: what logic we want to execute, dependencies : when do we want the effect function to execute)
  // mounting
  useEffect(
    () => {
      console.log("useEffect hook is called");
    },
    [
      // on which value changes the effect function will be called
    ]
  );
  // updating
  useEffect(() => {
    console.log("useEffect updating hook is called");
  }, [count]);
  useEffect(() => {
    console.log("useEffect updating hook1 is called");
  }, [count1]);
  // unmounting
  useEffect(() => {
    return () => {
      console.log("useEffect unmounting hook is called");
    };
  }, []);
  return (
    <div>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button onClick={() => setCount1(count1 + 1)}>Increment 1</button>

      <h1>Demo Component</h1>
      <p>some more content</p>
      <p>Hello from {name}</p>
      <p>{name.toUpperCase()}</p>
      <p>{9 + 8}</p>
    </div>
  );
}
export default Demo;
