// ts basics
// variable_name:data_type
let a: number;
a = "test";

// type inference
let b = 10;

function test(a: string, b: number) {}
test(1, 2);

const demo = (a: number, b?: number) => {};
demo(`1`);

// unions|intersection|narrowing
let d: number | string | boolean;
d = 10;
d = "test";
d = true;

// custom data types
interface Person {
  name: string;
  age: number;
}
type User = {
  name: string;
  age: number;
};
const p: Person = { name: "test" };
const p1: User = { name: "test" };

// extending types
interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
}
interface Cart extends Product {
  qty: number;
}
// types
type Product1 = {
  id: number;
  name: string;
  description: string;
  price: number;
};
// utils
// Omit, Pick
type Cart1 = Omit<Product1, "description" | "id"> & {
  qty: number;
};
const cart: Cart = {};
const cart1: Cart1 = {};

// nullable types
let a1: number | null;
a1 = null;

type User1 = {
  name: string;
  age?: number; // optional property
};
const u1: User1 = { name: "" };
// utils : Required
const u2: Required<User1> = {};
const u3: Partial<User1> = {};

type Todo = { id: number; description: string };
const t: Readonly<Todo> = { id: 1, description: "test data" };
t.id = 2;

// arrays
let a2: string[];
let a3: Array<string>;

// enums
enum Month {
  January = "Jan",
  Feburary = "Feb",
  March = "Mar",
}

const m: Month = Month.January;
