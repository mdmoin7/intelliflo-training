import Axios from "axios";
import { ProductType } from "../types";

export const getProducts = () => {
  const url =
    "https://raw.githubusercontent.com/mdmoin7/Random-Products-Json-Generator/master/products.json"; // paste json url here
  return Axios.get<ProductType[]>(url);
};
