import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import Currency from "./Currency"; // Adjust the import path as necessary
import useCurrency from "../hooks/useCurrency"; // Adjust the import path as necessary

// Mock the useCurrency hook
jest.mock("../hooks/useCurrency", () => ({
  __esModule: true,
  default: jest.fn(),
}));

describe("Currency Component", () => {
  const changeCurrencyMock = jest.fn();
  const setStorageDataMock = jest.fn();

  beforeEach(() => {
    (useCurrency as jest.Mock).mockReturnValue({
      code: "USD", // Initial selected currency
      setStorageData: setStorageDataMock,
    });
  });

  test("calls changeCurrency and setStorageData on selection change", () => {
    render(<Currency changeCurrency={changeCurrencyMock} />);

    // Open the select menu
    const selectElement = screen.getByRole("combobox");
    fireEvent.mouseDown(selectElement); // Simulate opening the dropdown

    // Select 'EUR'
    const euroOption = screen.getByText("EUR");
    fireEvent.click(euroOption); // Simulate clicking the 'EUR' option

    // Check if changeCurrency and setStorageData were called with 'EUR'
    expect(changeCurrencyMock).toHaveBeenCalledWith("EUR");
    expect(setStorageDataMock).toHaveBeenCalledWith("EUR");
  });
});
