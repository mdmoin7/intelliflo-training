// import { Typography } from "@mui/material";
// import Box from "@mui/material/Box";
// import { PropsWithChildren } from "react";
// import { Link } from "react-router-dom";

// function Menu({ children }: PropsWithChildren) {
//   return (
//     <Box
//       sx={{
//         display: "flex",
//         alignItems: "center",
//         justifyContent: "space-between",
//       }}
//     >
//       <Box
//         gap={4}
//         sx={{
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "center",
//         }}
//       >
//         {DATA.map((item) => (
//           <Link to={item.link}>
//             <Typography>{item.text}</Typography>
//           </Link>
//         ))}
//       </Box>
//       {children}
//     </Box>
//   );
// }
// export default Menu;

import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import AdbIcon from "@mui/icons-material/Adb";
import { useNavigate } from "react-router-dom";
import { PropsWithChildren } from "react";

const DATA = [
  { link: "/", text: "Home" },
  { link: "/products", text: "Products" },
  { link: "/checkout", text: "Checkout" },
];
function MyMenu({ children }: PropsWithChildren) {
  const navigate = useNavigate();

  return (
    <AppBar position="relative">
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          <AdbIcon sx={{ display: { xs: "none", md: "flex" }, mr: 1 }} />
          <Typography
            variant="h6"
            noWrap
            component="a"
            href="/core"
            sx={{
              mr: 2,
              display: { xs: "none", md: "flex" },
              fontFamily: "monospace",
              fontWeight: 700,
              letterSpacing: ".3rem",
              color: "inherit",
              textDecoration: "none",
            }}
          >
            LOGO
          </Typography>

          <AdbIcon sx={{ display: { xs: "flex", md: "none" }, mr: 1 }} />
          <Typography
            variant="h5"
            noWrap
            component="a"
            href="#app-bar-with-responsive-menu"
            sx={{
              mr: 2,
              display: { xs: "flex", md: "none" },
              flexGrow: 1,
              fontFamily: "monospace",
              fontWeight: 700,
              letterSpacing: ".3rem",
              color: "inherit",
              textDecoration: "none",
            }}
          >
            LOGO
          </Typography>
          <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
            {DATA.map((d) => (
              <Button
                key={d.link}
                onClick={() => navigate(d.link)}
                sx={{ my: 2, color: "white", display: "block" }}
              >
                {d.text}
              </Button>
            ))}
          </Box>
          <Box sx={{ flexGrow: 0, backgroundColor: "white" }}>{children}</Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
}
export default MyMenu;
