import { PropsWithChildren } from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";

function CustomCard({ children }: PropsWithChildren) {
  return (
    <Card>
      <CardContent>{children}</CardContent>
    </Card>
  );
}
export default CustomCard;
