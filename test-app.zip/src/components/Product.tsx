import Rating from "@mui/material/Rating";
import { ProductType } from "../types";
import Card from "./Card";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid2";
import { Stack } from "@mui/material";
import Image from "./Image";
import { useContext } from "react";
import { CurrencyContext } from "../context";
import useCurrency from "../hooks/useCurrency";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { RootState } from "../store";
// datatype definition
type Props = {
  data: ProductType;
  btnClick: (id: number) => void;
};

function Product({ data, btnClick }: Props) {
  const { code, getFormattedValue } = useCurrency();
  const currencyCode = useSelector((state: RootState) => state.currency); // undefined => INR => USD

  const renderStock = () => {
    if (data.productStock > 0) {
      return (
        <Button
          variant="contained"
          color="primary"
          onClick={() => btnClick(data.productId)}
        >
          Add to Cart
        </Button>
      );
    }
    return <p>Out of Stock</p>;
  };
  return (
    <Card>
      <Stack spacing={2}>
        <Grid size={12}>
          <Link to={`/details/${data.productId}`}>
            <Image src={data.productImage} />
          </Link>
        </Grid>
        <Typography
          variant={"h6"}
          textTransform={"capitalize"}
          textAlign={"center"}
        >
          {data.productName}
        </Typography>
        <Grid container>
          <Grid size={6}>
            <Typography variant={"h6"}>
              {currencyCode}
              {getFormattedValue(data.productPrice)}
            </Typography>
          </Grid>
          <Grid size={6}>
            <Rating
              name="half-rating-read"
              defaultValue={data.rating}
              precision={0.5}
              readOnly
            />
          </Grid>
        </Grid>{" "}
        {data.productStock > 0 ? (
          <Button
            variant="outlined"
            color="primary"
            onClick={() => btnClick(data.productId)}
          >
            Add to Cart
          </Button>
        ) : null}
        {/* <ProductButton /> */}
        {/* {renderStock()} */}
      </Stack>
    </Card>
  );
}
export default Product;
