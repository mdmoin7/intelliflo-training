import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import { useContext, useState } from "react";
import { CurrencyContext } from "../context";
import useCurrency from "../hooks/useCurrency";
import { updateCurrency } from "../store/slices/currencySlice";
import { useDispatch } from "react-redux";

type Props = {
  changeCurrency: (code: string) => void;
};

function Currency({ changeCurrency }: Props) {
  const codes = ["INR", "USD", "CAD", "GBP", "EUR"];
  const { code: selectedCode, setStorageData } = useCurrency();
  const dispatch = useDispatch();
  const handleChange = (event: SelectChangeEvent) => {
    let c = event.target.value;
    changeCurrency(c);
    dispatch(updateCurrency(c)); // store action : every action must be dispatched
    setStorageData(c);
  };

  return (
    <Box sx={{ backgroundColor: "white" }}>
      <FormControl>
        <Select value={selectedCode} onChange={handleChange}>
          {codes.map((c) => (
            <MenuItem value={c} key={c}>
              {c}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );
}

export default Currency;
