import { render, screen } from "@testing-library/react";
import CustomCard from "./Card"; // Adjust the import path as necessary

describe("CustomCard", () => {
  test("renders children correctly", () => {
    render(
      <CustomCard>
        <h1>Test Title</h1>
        <p data-testid="p1">This is a test paragraph.</p>
        <button>Button</button>
      </CustomCard>
    );

    // Check if the title and paragraph are in the document
    expect(screen.getByText(/Test Title/i)).toBeInTheDocument();
    expect(screen.getByTestId("p1")).toBeInTheDocument();
    expect(screen.getByRole("button")).toBeInTheDocument();
  });
});
// npm run test Card.test.tsx
