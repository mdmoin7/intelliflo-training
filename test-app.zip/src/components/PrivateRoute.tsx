import { PropsWithChildren } from "react";
import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
import { RootState } from "../store";

function PrivateRoute({ children }: PropsWithChildren) {
  const isLoggedIn = useSelector((state: RootState) => state.user !== null); // value comes from redux/context
  if (!isLoggedIn) {
    return <Navigate to={"/login"} />;
  }
  return <>{children}</>;
}
export default PrivateRoute;
