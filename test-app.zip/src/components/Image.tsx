import { useState } from "react";

export default function Image({ src }: { src: string }) {
  const [source, setSource] = useState(src);
  return (
    <img
      src={source}
      onError={() => setSource("https://placehold.co/400")}
      loading="lazy"
    />
  );
}
