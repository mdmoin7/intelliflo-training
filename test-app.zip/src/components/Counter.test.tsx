import { render, screen, fireEvent } from "@testing-library/react";
import Counter from "./Counter";

describe("Counter Component", () => {
  test("should render with count as 0", () => {
    render(<Counter />);
    expect(screen.getByText("clicked :0")).toBeInTheDocument();
  });
  test("Increment count by 1", () => {
    render(<Counter />);
    const button = screen.getByText("Increment");
    fireEvent.click(button);
    expect(screen.getByText("clicked :1")).toBeInTheDocument();
  });
  test("Decrement count by 1", () => {
    render(<Counter />);
    const button = screen.getByText("Decrement");
    fireEvent.click(button);
    expect(screen.getByText("clicked :-1")).toBeInTheDocument();
  });
  test("Reset count to 0", () => {
    render(<Counter />);
    const button = screen.getByText("Reset");
    fireEvent.click(button);
    expect(screen.getByText("clicked :0")).toBeInTheDocument();
  });
});
