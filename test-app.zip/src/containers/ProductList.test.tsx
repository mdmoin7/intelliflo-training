import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import configureStore from "redux-mock-store";
import { SnackbarProvider } from "notistack";
import ProductList from "./ProductList"; // Adjust the import path as necessary
import useProducts from "../hooks/useProducts";
import { addItem } from "../store/slices/cartSlice";

// Define the type for the return value of useProducts
interface UseProductsReturn {
  plist: { productId: number; name: string }[];
  isLoading: boolean;
  page: number;
  updatePageNo: (page: number) => void;
}

// Mock the useProducts hook
jest.mock("react-route-dom");
jest.mock("../hooks/useProducts");
// Create a mock store
const mockStore = configureStore([]);

describe("ProductList", () => {
  let store: any;

  beforeEach(() => {
    store = mockStore({
      cart: { items: [] },
    });

    // Mock the implementation of useProducts
    (useProducts as jest.Mock).mockReturnValue({
      plist: [
        { productId: 1, name: "Product 1" },
        { productId: 2, name: "Product 2" },
      ],
      isLoading: false,
      page: 1,
      updatePageNo: jest.fn(),
    } as UseProductsReturn);
  });

  test("renders loading state", () => {
    (useProducts as jest.Mock).mockReturnValueOnce({
      plist: [],
      isLoading: true,
      page: 1,
      updatePageNo: jest.fn(),
    } as UseProductsReturn);

    render(
      <Provider store={store}>
        <SnackbarProvider>
          <ProductList />
        </SnackbarProvider>
      </Provider>
    );

    expect(screen.getByRole("progressbar")).toBeInTheDocument();
  });

  test("renders product list", () => {
    render(
      <Provider store={store}>
        <SnackbarProvider>
          <ProductList />
        </SnackbarProvider>
      </Provider>
    );

    expect(screen.getByText("Product 1")).toBeInTheDocument();
    expect(screen.getByText("Product 2")).toBeInTheDocument();
  });

  test("adds item to cart and navigates to cart", () => {
    const mockNavigate = jest.fn();
    jest.mock("react-router-dom", () => ({
      useNavigate: () => mockNavigate,
    }));

    render(
      <Provider store={store}>
        <SnackbarProvider>
          <ProductList />
        </SnackbarProvider>
      </Provider>
    );

    const addButton = screen.getByText("Add to Cart"); // Adjust based on your button text
    fireEvent.click(addButton);

    expect(store.getActions()).toEqual([
      addItem({ productId: 1, name: "Product 1" }),
    ]);
    expect(mockNavigate).toHaveBeenCalledWith("/cart");
  });
});
