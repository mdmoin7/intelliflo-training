import { SyntheticEvent, useEffect, useRef, useState } from "react";

function Checkout() {
  const [name, setName] = useState("");
  const emailRef = useRef<HTMLInputElement>(null);
  const saveData = (e: SyntheticEvent) => {
    e.preventDefault(); // cancels the default behavior of the event
    console.log("form submission logic here", name, emailRef.current?.value);
  };
  useEffect(() => {
    if (emailRef.current) {
      emailRef.current.focus();
    }
  }, [emailRef]);
  return (
    <form onSubmit={(e) => saveData(e)}>
      {/* Controlled */}
      <input
        type="text"
        placeholder="name"
        onChange={(e) => setName(e.target.value)}
      />
      {name === "" ? <small>Name is required</small> : null}
      {/* Uncontrolled */}
      <input type="text" placeholder="email" ref={emailRef} />
      {emailRef.current && emailRef.current.value === "" ? (
        <small>Email is required</small>
      ) : null}
      <button type="submit">Submit</button>
    </form>
  );
}
export default Checkout;
