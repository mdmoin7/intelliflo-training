import { useEffect } from "react";
import { useParams } from "react-router-dom";

function ProductDetail() {
  const params: any = useParams(); // path params : /details/1234
  useEffect(() => {
    // data fetch logic here
  }, [params]);
  return (
    <div>
      <h1>Product Detail</h1>
      <p>PID : {params.pid}</p>
    </div>
  );
}
export default ProductDetail;
