import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../store";
import {
  TableContainer,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Button,
} from "@mui/material";
import { removeItem } from "../store/slices/cartSlice";

function Cart() {
  const cartItems = useSelector((state: RootState) => state.cart);
  const dispatch = useDispatch();
  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Price</TableCell>
            <TableCell></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {cartItems.map((row) => (
            <TableRow key={row.productId}>
              <TableCell component="th" scope="row">
                {row.productName}
              </TableCell>
              <TableCell align="right">{row.productPrice}</TableCell>
              <TableCell align="right">
                <Button
                  color="error"
                  variant="outlined"
                  onClick={() => dispatch(removeItem(row.productId))}
                >
                  &times;
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
export default Cart;
