function ErrorPage() {
  return (
    <div>
      <h1>404 Error</h1>
      <h3>Page not found</h3>
    </div>
  );
}
export default ErrorPage;
