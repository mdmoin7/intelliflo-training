"use client";

import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import useLogin from "../hooks/useLogin";
import { ErrorBoundary } from "react-error-boundary";

const LoginSchema = Yup.object().shape({
  email: Yup.string().required().email(),
  password: Yup.string()
    .required()
    .min(6, "Password must be at least 6 characters"),
});

function Login() {
  const login = useLogin();
  // throw "some error";
  return (
    <ErrorBoundary fallback={<div>Something went wrong</div>}>
      <Formik
        validationSchema={LoginSchema}
        initialValues={{ email: "", password: "" }}
        onSubmit={({ email, password }) => login(email, password)}
      >
        <Form>
          <Field type="email" name="email" placeholder="Email" />
          <ErrorMessage name="email" />
          <Field type="password" name="password" placeholder="Password" />
          <ErrorMessage name="password" />
          <button type="submit">Login</button>
        </Form>
      </Formik>
    </ErrorBoundary>
  );
}
export default Login;
