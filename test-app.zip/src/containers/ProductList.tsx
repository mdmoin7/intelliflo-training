import Grid from "@mui/material/Grid2";
import Product from "../components/Product";
import useProducts from "../hooks/useProducts";
import CircularProgress from "@mui/material/CircularProgress";
import { useNavigate } from "react-router-dom";
import Pagination from "@mui/material/Pagination";
import { useSnackbar } from "notistack";
import { useDispatch } from "react-redux";
import { addItem } from "../store/slices/cartSlice";
import { ProductType } from "../types";

function ProductList() {
  const { plist, isLoading, page, updatePageNo } = useProducts();
  const { enqueueSnackbar } = useSnackbar();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleClick = (item: ProductType) => {
    enqueueSnackbar("Item added to Cart");

    dispatch(addItem(item));
    navigate("/cart");
  };

  if (isLoading) {
    return <CircularProgress size="3rem" />;
  }
  return (
    <Grid container spacing={4}>
      <Grid size={12} container>
        {plist.map((item) => (
          <Grid size={3} key={item.productId}>
            <Product data={item} btnClick={() => handleClick(item)} />
          </Grid>
        ))}
      </Grid>
      <Grid
        size={12}
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Pagination
          count={10}
          page={page}
          variant="outlined"
          color="primary"
          onChange={(e, page) => updatePageNo(page)}
        />
      </Grid>
    </Grid>
  );
}
export default ProductList;
