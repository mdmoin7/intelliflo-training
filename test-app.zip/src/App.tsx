import { Container } from "@mui/material";
import ProductList from "./containers/ProductList";
import Currency from "./components/Currency";
import { CurrencyContext } from "./context";
import { useEffect, useState } from "react";
import useCurrency from "./hooks/useCurrency";
import AppRouter from "./AppRouter";
import { BrowserRouter } from "react-router-dom";
import Menu from "./components/Menu";
import { SnackbarProvider, VariantType, useSnackbar } from "notistack";
import { Provider } from "react-redux";
import { persistor, store } from "./store";
import { PersistGate } from "redux-persist/integration/react";

function App() {
  const [code, setCode] = useState("INR");
  const { getStorageData } = useCurrency();
  useEffect(() => {
    setCode(getStorageData());
  }, []);
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <BrowserRouter>
          <SnackbarProvider
            maxSnack={5}
            anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
            autoHideDuration={3000}
          >
            <Container maxWidth={false}>
              <CurrencyContext.Provider value={code}>
                <Menu>
                  <Currency changeCurrency={(c) => setCode(c)} />
                </Menu>
                <AppRouter />
              </CurrencyContext.Provider>
            </Container>
          </SnackbarProvider>
        </BrowserRouter>
      </PersistGate>
    </Provider>
  );
}

export default App;
