module.exports = {
  transformIgnorePatterns: ["node_modules/(?!(axios)/)"],
};
